export class Invoice {
    User_ID: String;
    Employee_name: String;
    Basic_charge: String;
    Cost: String;
    Total_Cost: String;
}
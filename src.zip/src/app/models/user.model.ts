export class User {
    fname: string;
    lname: string;
    email: string;
    mobileno: string;
    password: string;
    worktype:String;
    rating: string;
    comments: string;
    image: String;
    bio:string;
    invoice: string;
}

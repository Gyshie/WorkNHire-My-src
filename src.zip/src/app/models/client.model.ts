export class Client {
    fname: String;
    lname: String;
    address:String;
    email: String;
    mobileno: String;
    password: String;
    rating:String;
    comments:String;
    image:String 
}
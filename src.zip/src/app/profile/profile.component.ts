import { AuthService } from './../services/auth.service';
import { Component,OnInit, } from '@angular/core';
import { User } from '../models/user.model';

/*class ImageSnippet {

  pending: boolean = false;
  status: string = 'init';

  constructor(public src: string, public file: File) {}
}*/

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

/*export class ImageUploadComponent implements OnInit {

  selectedFile: ImageSnippet;

  constructor(private imageService: ImageService){}

  private onSuccess() {
    this.selectedFile.pending = false;
    this.selectedFile.status = 'ok';
  }

  private onError() {
    this.selectedFile.pending = false;
    this.selectedFile.status = 'fail';
    this.selectedFile.src = '';
  }

  processFile(imageInput: any) {
    const file: File = imageInput.files[0];
    const reader = new FileReader();

    reader.addEventListener('load', (event: any) => {

      this.selectedFile = new ImageSnippet(event.target.result, file);
      this.selectedFile.pending = true;
      this.imageService.uploadImage(this.selectedFile.file).subscribe(
        (res) => {
        
        },
        (err) => {
        
        })
    });

    reader.readAsDataURL(file);
  }
}*/

export class ProfileComponent implements OnInit {
  user: User; 

  showText(title:string) {
    if(title!="")
  {
     alert(title);
  }
  else
  {
   alert("Fill the name first!!!");
  }
  }

  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.user = this.auth.getUser();
  }
//comment submission
  comment(form) {
    console.log(form.value);
}


}

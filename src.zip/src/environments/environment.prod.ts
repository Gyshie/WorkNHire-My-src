export const environment = {
  production: true,
  baseUrl: 'https://cryptic-wildwood-49687.herokuapp.com/api/'
};
